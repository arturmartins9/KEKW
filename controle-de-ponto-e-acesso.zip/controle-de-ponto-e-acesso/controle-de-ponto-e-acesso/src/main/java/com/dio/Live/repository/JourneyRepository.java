package com.dio.Live.repository;

import org.springframework.beans.factory.annotation.Autowired;

public interface JourneyRepository {

    @Autowired
    //JourneyRepository jornadaRepository;
}
